//
//  ResponseDataFactory.swift
//  LennoxDemoProjectUITests
//
//  Created by Bargav Munusamy Sampath on 16/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import Foundation

class ResponseDataFactory {
    
    static func responseData(filename: String) -> Data {
        guard let path = Bundle(for: ResponseDataFactory.self).path(forResource: filename, ofType: "json", inDirectory: "Responses"),
            let data = try? NSData.init(contentsOfFile: path, options: []) else {
                fatalError("\(filename).json not found")
        }
        return data as Data
    }
}
