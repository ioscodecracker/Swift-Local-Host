//
//  RatingPageUITests.swift
//  LennoxDemoProjectUITests
//
//  Created by Bargav on 07/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import XCTest

class RatingPageUITests : XCTestCase {
    
    let app = XCUIApplication()
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        

        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false
        
        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }
    
    
    
    func test_1_ValidCredentials() {
        
        let validEmailId = "msb@gmail.com"
        let validPassword = "1234"
        
        let email = app.textFields["Email Id"]
        XCTAssertTrue(email.exists)
        email.tap()
        email.typeText(validEmailId)
       
        let password = app.secureTextFields["Password"]
        XCTAssertTrue(password.exists)
        password.tap()
        password.typeText(validPassword)
     
    
        XCTAssertTrue(app.buttons["Login"].exists)
        app.buttons["Login"].tap()
        
        XCTAssertTrue(app.alerts["Login"].scrollViews.otherElements.buttons["OK"].exists)
        app.alerts["Login"].scrollViews.otherElements.buttons["OK"].tap()
        
        let homePage = app.navigationBars["Movie Rating Page"]
        
        expectation(for:NSPredicate(format:"exists == 1"), evaluatedWith:homePage,handler:nil)
        waitForExpectations(timeout: 5, handler: nil)
        
        XCTAssertTrue(homePage.exists)

    }
    
    func test_2_MovieTextField_Empty_NoRatingGiven_SubmitButtonClicked() {
        
        let movieName = ""
        
        let movieTF = app.textFields["Enter Movie Name"]
        XCTAssertTrue(movieTF.exists)
        movieTF.tap()
        movieTF.clearAndEnterText(text:movieName)
        
        XCTAssertTrue(app.toolbars["Toolbar"].buttons["Done"].exists)
        app.toolbars["Toolbar"].buttons["Done"].tap()
        
        XCTAssertTrue(app/*@START_MENU_TOKEN@*/.staticTexts["Submit"]/*[[".buttons[\"Submit\"].staticTexts[\"Submit\"]",".staticTexts[\"Submit\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.exists)
        app/*@START_MENU_TOKEN@*/.staticTexts["Submit"]/*[[".buttons[\"Submit\"].staticTexts[\"Submit\"]",".staticTexts[\"Submit\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        
        XCTAssertTrue(app.alerts["Movie Name"].scrollViews.otherElements.buttons["OK"].exists)
        app.alerts["Movie Name"].scrollViews.otherElements.buttons["OK"].tap()
        
        
    }
    
    func test_3_MovieTextField_Empty_RatingGiven_SubmitButtonClicked() {

        
        let movieName = "Bhahuballi"

        let movieTF = app.textFields["Enter Movie Name"]
        XCTAssertTrue(movieTF.exists)
        movieTF.tap()
        movieTF.clearAndEnterText(text:movieName)

        XCTAssertTrue(app.toolbars["Toolbar"].buttons["Done"].exists)
        app.toolbars["Toolbar"].buttons["Done"].tap()
        
        let ratingElement = app.otherElements["Rating"]
        XCTAssertTrue(ratingElement.exists)
        ratingElement.tap()
        app.staticTexts["3.0"].tap()

        let submitButton = app.buttons["Submit"]
        XCTAssert(submitButton.exists)
        submitButton.tap()

        let okButton = app.alerts[movieName].scrollViews.otherElements.buttons["OK"]
        XCTAssertTrue(okButton.exists)
        okButton.tap()
        
        XCTAssertTrue(app.navigationBars["Movie Rating Page"].buttons["Log Out"].exists)
        app.navigationBars["Movie Rating Page"].buttons["Log Out"].tap()

        let loginPage = app.navigationBars["Lennox Technology"]
        expectation(for:NSPredicate(format:"exists == 1"), evaluatedWith:loginPage,handler:nil)
        waitForExpectations(timeout: 5, handler: nil)

        XCTAssertTrue(loginPage.exists)
    }

   
}

