//
//  RegisterPageUITests.swift
//  LennoxDemoProjectUITests
//
//  Created by Bargav on 07/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import XCTest

class RegisterPageUITests: XCTestCase {

let app = XCUIApplication()

override func setUpWithError() throws {
    // Put setup code here. This method is called before the invocation of each test method in the class.
    
    // In UI tests it is usually best to stop immediately when a failure occurs.
    continueAfterFailure = false

    
    // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
     //app.buttons["SignUp"].tap()
}

override func tearDownWithError() throws {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
  }
    
    func test_1_AllFieldsEmpty(){
        
        XCTAssertTrue(app.buttons["SignUp"].exists)
        app.buttons["SignUp"].tap()
        
        let emptyStr = ""
        
        XCTAssertTrue(app.textFields["Name"].exists)
        app.textFields["Name"].clearAndEnterText(text: emptyStr)
        
        XCTAssertTrue(app.textFields["Email Id"].exists)
        app.textFields["Email Id"].clearAndEnterText(text: emptyStr)
        
        XCTAssertTrue(app.textFields["Mobile Number"].exists)
        app.textFields["Mobile Number"].clearAndEnterText(text: emptyStr)
        
        XCTAssertTrue(app.secureTextFields["Password"].exists)
        app.secureTextFields["Password"].clearAndEnterText(text: emptyStr)
        
        let doneButton = app.toolbars["Toolbar"].buttons["Done"]
        XCTAssertTrue(doneButton.exists)
        doneButton.tap()
        
        XCTAssertTrue(app.buttons["SignUp"].exists)
        app.buttons["SignUp"].tap()
        
        XCTAssertTrue(app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].exists)
        
        app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].tap()
      
    }
    
    func test_2_NameGivenRestFieldsEmpty() {
        
        let nameField = app.textFields["Name"]
        XCTAssertTrue(nameField.exists)
        nameField.tap()
        nameField.typeText("Muthukumarios")
        
        let doneButton = app.toolbars["Toolbar"].buttons["Done"]
        XCTAssertTrue(doneButton.exists)
        doneButton.tap()
        
        XCTAssertTrue(app.buttons["SignUp"].exists)
        app.buttons["SignUp"].tap()
        
        XCTAssertTrue(app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].exists)
        app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].tap()
    }
 
   func test_3_NameAndEmailGivenRestFieldsEmpty() {
    
        let emailField = app.textFields["Email Id"]
        XCTAssertTrue(emailField.exists)
        emailField.tap()
        emailField.typeText("msb@gmail.com")
    
        let doneButton = app.toolbars["Toolbar"].buttons["Done"]
        XCTAssertTrue(doneButton.exists)
        doneButton.tap()
    
        XCTAssertTrue(app.buttons["SignUp"].exists)
        app.buttons["SignUp"].tap()
    
        XCTAssertTrue(app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].exists)
        app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].tap()
    }
    
    func test_4_NameAndEmailAndMobileNoGivenRestFieldsEmpty() {
        
        let mobNoTextfield = app.textFields["Mobile Number"]
        XCTAssertTrue(mobNoTextfield.exists)
        mobNoTextfield.tap()
        mobNoTextfield.typeText("9901234565432")
        
        let doneButton = app.toolbars["Toolbar"].buttons["Done"]
        XCTAssertTrue(doneButton.exists)
        doneButton.tap()
        
        XCTAssertTrue(app.buttons["SignUp"].exists)
        app.buttons["SignUp"].tap()
        
        XCTAssertTrue(app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].exists)
        app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].tap()
        
       }
    
    func test_5_NameAndEmailAndMobileNoAndSecuredPasswordGivenRestFieldsEmpty() {
          
        let passwordTextField = app.secureTextFields["Password"]
        XCTAssertTrue(passwordTextField.exists)
        passwordTextField.tap()
        passwordTextField.typeText("vijay@1")
        
        let doneButton = app.toolbars["Toolbar"].buttons["Done"]
        XCTAssertTrue(doneButton.exists)
        doneButton.tap()
        
        XCTAssertTrue(app.buttons["SignUp"].exists)
        app.buttons["SignUp"].tap()
        
        XCTAssertTrue(app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].exists)
        app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].tap()
             
    }
    
    func test_6_EnteringUnregisteredMobileAndRegisteredEmailId() {
        
        
        let mobNum = app.textFields["Mobile Number"]
        XCTAssertTrue(mobNum.exists)
        mobNum.tap()
        mobNum.clearAndEnterText(text:"6077805952")     //new mobNo
        
        let doneButton = app.toolbars["Toolbar"].buttons["Done"]
        XCTAssertTrue(doneButton.exists)
        doneButton.tap()
        
        XCTAssertTrue(app.buttons["SignUp"].exists)
        app.buttons["SignUp"].tap()
        
        XCTAssertTrue(app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].exists)
        app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].tap()
    }
    
    func test_7_EnteringInvalidEmailId() {
          
        let emailField = app.textFields["Email Id"]
        XCTAssertTrue(emailField.exists)
        emailField.tap()
        emailField.clearAndEnterText(text:"muthu.co.in")
        
        let doneButton = app.toolbars["Toolbar"].buttons["Done"]
        XCTAssertTrue(doneButton.exists)
        doneButton.tap()
        
        XCTAssertTrue(app.buttons["SignUp"].exists)
        app.buttons["SignUp"].tap()
        
        XCTAssertTrue(app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].exists)
        app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].tap()

    }
    
    

    
    func test_8_EnteringUnregisteredEmailIdAndMobileNumber() {
        let emailField = app.textFields["Email Id"]
        XCTAssertTrue(emailField.exists)
        emailField.tap()
        emailField.clearAndEnterText(text:"ms19ieu345@gmail.com")  //new emailid
        
        let doneButton = app.toolbars["Toolbar"].buttons["Done"]
        XCTAssertTrue(doneButton.exists)
        doneButton.tap()
        
        XCTAssertTrue(app.buttons["SignUp"].exists)
        app.buttons["SignUp"].tap()
        
        XCTAssertTrue(app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].exists)
        app.alerts["SignUp"].scrollViews.otherElements.buttons["OK"].tap()
        
        let loginPage = app.navigationBars["Lennox Technology"]
        
        expectation(for:NSPredicate(format:"exists == 1"), evaluatedWith:loginPage,handler:nil)
        waitForExpectations(timeout: 5, handler: nil)
        
        XCTAssertTrue(loginPage.exists)
    }
    
}
  


