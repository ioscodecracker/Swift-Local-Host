//
//  UIString + Extension.swift
//  LennoxDemoProject
//
//  Created by Bargav Munusamy Sampath on 16/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import Foundation

extension String {
    var isValidContact: Bool {
        let phoneNumberRegex = "^[6-9]\\d{9}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneNumberRegex)
        let isValidPhone = phoneTest.evaluate(with: self)
        return isValidPhone
    }
}
