//
//  RegistrationDetails.swift
//  LennoxDemoProject
//
//  Created by Bargav Munusamy Sampath on 10/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import Foundation
import UIKit

struct RegistrationDetails:Encodable{
    
    let name:String
    let email:String
    let mobileNumber:String
    let password:String
}

// MARK: - ResponseModel
struct ResponseModel: Codable {
    let lastLogin: Int
    let userStatus, mobileNumber: String
    let created: Int
    let ownerID, socialAccount: String
    let phoneNumber: JSONNull?
    let name, responseModelClass, blUserLocale, userToken: String
    let updated: JSONNull?
    let email, objectID: String

    enum CodingKeys: String, CodingKey {
        case lastLogin, userStatus, mobileNumber, created
        case ownerID = "ownerId"
        case socialAccount, phoneNumber, name
        case responseModelClass = "___class"
        case blUserLocale
        case userToken = "user-token"
        case updated,email
        case objectID = "objectId"
    }
}

// MARK: - Encode/decode helpers

class JSONNull: Codable, Hashable {

    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
        return true
    }

    public var hashValue: Int {
        return 0
    }

    public init() {}

    public required init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if !container.decodeNil() {
            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encodeNil()
    }
}


