//
//  SignupViewController.swift
//  TaskApp
//
//  Created by Bargav on 01/10/20.
//  Copyright © 2020 apple. All rights reserved.
//

import UIKit
import CoreData

class SignupViewController: UIViewController {
    
    @IBOutlet weak var signUpBtnRef: UIButton!
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var mobileNumberTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
    }
    
    
    @IBAction func cancelButtonPressed(_ sender: UIBarButtonItem) {
        let rootVC = UIApplication.shared.windows.first?.rootViewController
        if let topVC = UIApplication.getTopViewController(){
            if rootVC?.children.first is RatingPageViewController {
                let vc = LoginViewController.sharedInstance.showVC(identifier:"LoginViewController")
                topVC.navigationController?.pushViewController(vc,animated:true)
            }
            else{
                topVC.navigationController?.popToRootViewController(animated:true)
            }
        }
    }
    
    //MARK:- EmailId Validation
    func validateEmailId(emailAddress: String) -> Bool {
        let REGEX: String
        REGEX = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}"
        return NSPredicate(format: "SELF MATCHES %@", REGEX).evaluate(with: emailAddress)
    }
    
    @IBAction func signupButtonTap(_ sender: Any) {
        
        guard let nameStr = nameTextField.text, !nameStr.isEmpty else {
            let alertController = UIAlertController(title: "SignUp", message: "Please Enter Name", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        
        guard let emailStr = emailTextField.text, !emailStr.isEmpty else {
            /// Please enter mob no.
            let alertController = UIAlertController(title: "SignUp", message: "Please Enter Email Id", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        
        //EmailId Validity Check
        guard let emailText = emailTextField.text, self.validateEmailId(emailAddress: emailText) else {
            let alertController = UIAlertController(title: "SignUp", message: "Please Enter Valid Email id", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        
        guard let mobNumberStr = mobileNumberTextField.text, !mobNumberStr.isEmpty, mobNumberStr.isValidContact else {
            let alertController = UIAlertController(title: "SignUp", message: "Please Enter a Valid Mobile Number", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        
        guard let passwordStr = passwordTextField.text, !passwordStr.isEmpty else {
            let alertController = UIAlertController(title: "SignUp", message: "Please Enter password", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        
        let registerDetails = RegistrationDetails(name: nameStr, email: emailStr, mobileNumber: mobNumberStr, password: passwordStr)
        
        APIHandler.sharedInstance.detailsRegisterAPI(registerDetails: registerDetails) { (logic,message) in
            switch logic {
            
            case true:
                let alertController = UIAlertController(title: "SignUp", message: message, preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: {_ in
                    self.navigationController?.popToRootViewController(animated: true)
                }))
                self.present(alertController, animated: true, completion:nil)
                
            case false:
                let alertController = UIAlertController(title: "SignUp", message: message, preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
            }
        }
        
    }
    
}









