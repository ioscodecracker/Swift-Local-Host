////
////  LoginViewController.swift
////  TaskApp
////
////  Created by apple on 01/10/20.
////  Copyright © 2020 apple. All rights reserved.
////
//
import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var emailidTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    let storyBoard = UIStoryboard(name: "Main", bundle: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated:Bool){
        super.viewWillAppear(animated)
        emailidTextField.text = ""
        passwordTextField.text = ""
    }
    
    @IBAction func loginBtnTap(_ sender: Any) {
        
        guard let emailStr = emailidTextField.text, !emailStr.isEmpty else {
            let alertController = UIAlertController(title: "Login", message: "Please Enter Email Id", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        
        guard let passwordStr = passwordTextField.text, !passwordStr.isEmpty else {
            let alertController = UIAlertController(title: "Login", message: "Please Enter Password", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        
        let loginModel = LoginModel(login: emailStr, password: passwordStr)
        let message = "Invalid Login or Password"
        
        APIHandler.sharedInstance.callingLoginAPI(loginModel: loginModel) { (result) in
            switch result{
            case .success(let jsonData):
                let name = (jsonData as! ResponseModel).name
                let email = (jsonData as! ResponseModel).email
                let userToken = (jsonData as! ResponseModel).userToken
                TokenService.tokenInstance.saveToken(token: userToken)
                
                print(userToken)
                
                let alertController = UIAlertController(title: "Login", message: "\(name) Login Success for email: \(email)", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: {_ in
                    let ratingPageVC = self.storyBoard.instantiateViewController(withIdentifier: "RatingPageViewController") as! RatingPageViewController
                    self.navigationController?.pushViewController(ratingPageVC, animated: true)
                }))
                self.present(alertController, animated: true, completion: nil)
                
            case .failure(let err):
                print(err.localizedDescription)
                let alertController = UIAlertController(title: "Login", message: message, preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
                return
            }
        }
    }
    
    @IBAction func signupButtonTap(_ sender: Any) {
        let registerVC = storyBoard.instantiateViewController(withIdentifier: "SignupViewController") as! SignupViewController
        self.navigationController?.pushViewController(registerVC, animated: true)
    }
}


