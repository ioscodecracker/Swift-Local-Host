//
//  NetworkOperations.swift
//  LennoxDemoProject
//
//  Created by Bargav Munusamy Sampath on 16/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import Foundation

class NetworkOperations {

    //private let baseUrl: String = "https://api.themoviedb.org/3/movie"
    
    private let baseUrl: String = "http://localhost:9001/3/movie"
}
