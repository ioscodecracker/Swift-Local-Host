//
//  TokenService.swift
//  LennoxDemoProject
//
//  Created by Bargav Munusamy Sampath on 11/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import UIKit

class TokenService{
    
    static let tokenInstance = TokenService()
    let key = TokenKey.userLogin
    
    let userDefault = UserDefaults.standard
    
    func saveToken(token:String){
        userDefault.set(token, forKey: key)
    }
    
    func getToken()->String{
        guard let token = userDefault.object(forKey: key ) as? String else{
            return ""
        }
        return token
    }
    
    func checkForLogin()->Bool{
        guard getToken() == "" else{return true}
        return false
    }
    
    func removeToken(){
        userDefault.removeObject(forKey: key)
    }
}
